#import "VGCoreAuto.tlb"     // 导入VGCoreAuto类型库: 这个文件在CorelDRAW 软件目录下可以找到
#define corel VGCore::IVGApplication
using namespace VGCore;
bool cql_OutlineColor(corel *cdr);
int cpg_main() {
  // 初始化COM库，使用多线程公寓模型
  HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

  if (SUCCEEDED(hr)) {
    // 创建一个指向CorelDRAW应用程序的指针，经测试 CorelDRAW 16 可以正常绑定， 安装毛子版的 CorelDRAW 2020 无法正常绑定
    VGCore::IVGApplicationPtr app(L"CorelDRAW.Application.16");

    // 设置应用程序为可见状态
    app->Visible = VARIANT_TRUE;
    // 获取当前活动的文档，如果没有则创建一个新文档
    auto doc = app->ActiveDocument;
    if (!doc)
      doc = app->CreateDocument();

    cql_OutlineColor(app);

    // 清理COM库的初始化
    CoUninitialize();
  }

  return 0;
}
bool cql_OutlineColor(corel *cdr)
{
    auto col = cdr->CreateCMYKColor(0, 100, 100, 0);
    auto s = cdr->ActiveShape;
    col-> CopyAssign(s->Outline->Color);
    col->ConvertToRGB();

    auto r = col->RGBRed;
    auto g = col->RGBGreen;
    auto b = col->RGBBlue;

    char buf[256] = { 0 };
    sprintf(buf, "@Outline.Color.rgb[.r='%d' And .g='%d' And .b='%d']", r, g, b);
    auto cql = _bstr_t(buf);
    auto sr = cdr->ActivePage->Shapes->FindShapes(_bstr_t(), cdrNoShape, VARIANT_TRUE, cql);
    sr->CreateSelection();

    return true;
}